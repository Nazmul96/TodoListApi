<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {
        return view('backend.login');
    }

    public function login()
    {
        return view('backend.admin_dashboard');
    }
}
