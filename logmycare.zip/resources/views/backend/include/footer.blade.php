</div>
    <script src="{{asset('backend/dist')}}/assets/vendors/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="{{asset('backend/dist')}}/assets/js/bootstrap.bundle.min.js"></script>

    <script src="{{asset('backend/dist')}}/assets/vendors/apexcharts/apexcharts.js"></script>
    <script src="{{asset('backend/dist')}}/assets/js/pages/dashboard.js"></script>

    <script src="{{asset('backend/dist')}}/assets/js/main.js"></script>
</body>

</html>