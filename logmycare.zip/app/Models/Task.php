<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    use HasFactory;
    protected $table = "tasks";
    protected $fillable = ['category_id','task_title','due_date','time_set','repeat'];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }
}
